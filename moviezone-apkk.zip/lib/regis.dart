import 'package:flutter/material.dart';
import 'package:netfy/login.dart';

class regis extends StatefulWidget {
  _regisState createState() => new _regisState();
}

class _regisState extends State<regis> {
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green[800],
        title: Text("Register", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0, color: Colors.white)),
      ),
      body: Container(
        color: Colors.green[800],
        width: double.infinity,
        height: double.infinity,
        // Batas Alas
        child: Center(
          child: Column(
            children: <Widget>[
              Column(
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(top: 8.0, bottom: 8.0),
                  ),
                  Center(
                    child: Row(
                      children: <Widget>[
                        Padding(
                          padding: EdgeInsets.only(left: 8.0, top: 8.0),
                        ),
                        Text(
                          "NETFY",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 28,
                          ),
                        ),
                        Image.asset(
                          "assets/play.png",
                          width: 25,
                          height: 25,
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 10.0, bottom: 20.0),
                  ),
                  Text('Nama Lengkap', style: TextStyle(color: Colors.white)),
                  //Nama Lengkap
                  Container(
                    width: 340,
                    height: 45,
                    child: TextButton(
                      style: TextButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                          side: BorderSide(width: 2.0, color: Colors.white),
                        ),
                      ),
                      onPressed: () {},
                      child: Text(
                        "Nama Lengkap",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18.0,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  //Nma Lengkap
                  Padding(
                    padding: EdgeInsets.only(top: 5.0, bottom: 5.0),
                  ),
                  Text('Username', style: TextStyle(color: Colors.white)),
                  //Username
                  Container(
                    width: 340,
                    height: 45,
                    child: TextButton(
                      style: TextButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                          side: BorderSide(width: 2.0, color: Colors.white),
                        ),
                      ),
                      onPressed: () {},
                      child: Text(
                        "Username",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18.0,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  //Username

                  Padding(
                    padding: EdgeInsets.only(top: 5.0, bottom: 5.0),
                  ),

                  Text('Jenis Kelamin', style: TextStyle(color: Colors.white)),
                  //Jenis Kelamin
                  Container(
                    width: 340,
                    height: 45,
                    child: TextButton(
                      style: TextButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                          side: BorderSide(width: 2.0, color: Colors.white),
                        ),
                      ),
                      onPressed: () {},
                      child: Text(
                        "Jenis Kelamin",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18.0,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  //Jenis Kelamin

                  Padding(
                    padding: EdgeInsets.only(top: 5.0, bottom: 5.0),
                  ),
                  Text('No. Telepon', style: TextStyle(color: Colors.white)),
                  //No. Telepon
                  Container(
                    width: 340,
                    height: 45,
                    child: TextButton(
                      style: TextButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                          side: BorderSide(width: 2.0, color: Colors.white),
                        ),
                      ),
                      onPressed: () {},
                      child: Text(
                        "No. Telepon",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18.0,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  //No. Telepon

                  Padding(
                    padding: EdgeInsets.only(top: 5.0, bottom: 5.0),
                  ),
                  Text('Email', style: TextStyle(color: Colors.white)),
                  //email
                  Container(
                    width: 340,
                    height: 45,
                    child: TextButton(
                      style: TextButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                          side: BorderSide(width: 2.0, color: Colors.white),
                        ),
                      ),
                      onPressed: () {},
                      child: Text(
                        "Email",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18.0,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  //email

                  Padding(
                    padding: EdgeInsets.only(top: 5.0, bottom: 5.0),
                  ),
                  Text('Password', style: TextStyle(color: Colors.white)),
                  //Password
                  Container(
                    width: 340,
                    height: 45,
                    child: TextButton(
                      style: TextButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                          side: BorderSide(width: 2.0, color: Colors.white),
                        ),
                      ),
                      onPressed: () {},
                      child: Text(
                        "******",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18.0,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  //Password
                  Padding(
                    padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
                  ),
                ],
              ),

              //Login button
              Container(
                width: 340,
                height: 45,
                child: TextButton(
                  style: TextButton.styleFrom(
                    backgroundColor: Colors.blue,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => login()));
                  },
                  child: Text(
                    "Regis",
                    style: TextStyle(
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              //Login product display
            ],
          ),
        ),
      ),
    );
  }
}
