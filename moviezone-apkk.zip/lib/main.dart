import 'package:flutter/material.dart';
import 'package:moviezone/splashscreen.dart';
import 'package:moviezone/movlist.dart';
import 'package:moviezone/profile.dart';

void main() {
  runApp(MyApp());
}

//class Myapp
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '',
      home: SplashScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

//class home
class Home extends StatefulWidget {
  _HomeState createState() => _HomeState();
}

//class home
class _HomeState extends State<Home> {
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.grey[800],
        title: Text("Moviezone", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0, color: Colors.white)),
        actions: <Widget>[
          IconButton(icon: new Icon(Icons.search, color: Colors.white)),
          InkWell(
            child: IconButton(icon: new Icon(Icons.person, color: Colors.white)),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => profile()));
            },
          ),
        ],
      ),

      // Menu Baru
      body: Container(
        color: Colors.blue[800],
        width: double.infinity,
        height: double.infinity,
        // Batas Alas
        child: Center(
          child: Column(
            children: <Widget>[
              Column(
                children: <Widget>[
                  Text("For You", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0, color: Colors.white)),

                  //highlight

                  Container(
                    width: 340,
                    height: 280,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10.0),
                      image: DecorationImage(
                        image: AssetImage('assets/dilan.jpg'),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 8.0, bottom: 8.0),
                  ),
                  //Daftar Film display
                  Text("Daftar Film", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0, color: Colors.white)),

                  Center(
                    child: Row(
                      children: <Widget>[
                        Padding(
                          padding: EdgeInsets.only(left: 8.0, right: 8.0),
                        ),
                        // menu sentuh 1
                        InkWell(
                          child: Container(
                            width: 120,
                            height: 180,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10.0),
                              image: DecorationImage(
                                image: AssetImage('assets/alin.jpg'),
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) => movlist()));
                          },
                        ),
                        // akhir menu sentuh 1
                        Padding(
                          padding: EdgeInsets.only(left: 8.0, right: 8.0),
                        ),
                        // menu sentuh 1
                        InkWell(
                          child: Container(
                            width: 120,
                            height: 180,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10.0),
                              image: DecorationImage(
                                image: AssetImage('assets/setan.jpg'),
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) => netfylist()));
                          },
                        ),
                        // akhir menu sentuh 1
                      ],
                    ),
                  ),
                  //end product display
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
