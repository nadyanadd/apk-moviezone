import 'package:flutter/material.dart';

class profile extends StatefulWidget {
  _profileState createState() => new _profileState();
}

class _profileState extends State<profile> {
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue[800],
        title: Text("Profile", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0, color: Colors.white)),
      ),
      body: Container(
        color: Colors.grey[800],
        width: double.infinity,
        height: double.infinity,
        // Batas Alas

        child: Column(
          children: <Widget>[
            Column(
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.only(top: 8.0, bottom: 8.0),
                ),
                Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100.0),
                    image: DecorationImage(
                      image: AssetImage('assets/person.jpg'),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
                ),
                Text('Nama Lengkap', style: TextStyle(color: Colors.white)),
                Text('Kalea', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18.0, color: Colors.white)),
                Padding(
                  padding: EdgeInsets.only(top: 5.0, bottom: 5.0),
                ),
                Text('Username', style: TextStyle(color: Colors.white)),
                Text('Kals', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18.0, color: Colors.white)),
                Padding(
                  padding: EdgeInsets.only(top: 5.0, bottom: 5.0),
                ),
                Text('Jenis Kelamin', style: TextStyle(color: Colors.white)),
                Text('Perempuan', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18.0, color: Colors.white)),
                Padding(
                  padding: EdgeInsets.only(top: 5.0, bottom: 5.0),
                ),
                Text('No. Telepon', style: TextStyle(color: Colors.white)),
                Text('085432345678', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18.0, color: Colors.white)),
                Padding(
                  padding: EdgeInsets.only(top: 5.0, bottom: 5.0),
                ),
                Text('Email', style: TextStyle(color: Colors.white)),
                Text('kals@gmail.com', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18.0, color: Colors.white)),
                Padding(
                  padding: EdgeInsets.only(top: 5.0, bottom: 5.0),
                ),
                Text('Password', style: TextStyle(color: Colors.white)),
                Text('******', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18.0, color: Colors.white)),
                Padding(
                  padding: EdgeInsets.only(top: 5.0, bottom: 5.0),
                ),
              ],
            ),

            //edit button
            Container(
              width: 340,
              height: 45,
              child: TextButton(
                style: TextButton.styleFrom(
                  backgroundColor: Colors.blue,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                onPressed: () {},
                child: Text(
                  "Edit",
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            //edit product display
          ],
        ),
      ),
    );
  }
}
